-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.27-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for ossiana_db
CREATE DATABASE IF NOT EXISTS `ossiana_db` /*!40100 DEFAULT CHARACTER SET armscii8 COLLATE armscii8_bin */;
USE `ossiana_db`;

-- Dumping structure for table ossiana_db.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.failed_jobs: ~0 rows (approximately)

-- Dumping structure for table ossiana_db.inspections
CREATE TABLE IF NOT EXISTS `inspections` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `file_inspection` varchar(255) NOT NULL,
  `damage_type` varchar(255) NOT NULL,
  `inspection_costs` varchar(255) NOT NULL,
  `tire_arrival` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspections_order_id_foreign` (`order_id`),
  KEY `inspections_user_id_foreign` (`user_id`),
  CONSTRAINT `inspections_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `inspections_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.inspections: ~0 rows (approximately)
INSERT INTO `inspections` (`id`, `order_id`, `user_id`, `file_inspection`, `damage_type`, `inspection_costs`, `tire_arrival`, `status`, `created_at`, `updated_at`) VALUES
	(3, 13, 5, '1686925083_inspection.pdf', 'major', '5000000', '2023-06-18', 'success', '2023-06-16 07:18:03', '2023-06-16 07:18:03'),
	(4, 14, 5, '1687435651_Payment.pdf', 'major', '3000000', '2023-06-23', 'success', '2023-06-22 05:07:31', '2023-06-22 05:07:31');

-- Dumping structure for table ossiana_db.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.migrations: ~9 rows (approximately)
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_100000_create_password_reset_tokens_table', 1),
	(2, '2014_1_1_000000_create_roles_table', 1),
	(3, '2014_2_2_000000_create_users_table', 1),
	(4, '2014_3_3_000000_create_orders_table', 1),
	(5, '2014_4_4_000000_create_inspections_table', 1),
	(6, '2014_5_5_000000_create_schedullers_table', 1),
	(7, '2014_6_6_000000_create_report_table', 1),
	(8, '2019_08_19_000000_create_failed_jobs_table', 1),
	(9, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- Dumping structure for table ossiana_db.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(255) NOT NULL,
  `queue_number` varchar(255) DEFAULT NULL,
  `book_date` date NOT NULL,
  `total_tire` int(11) NOT NULL,
  `size_tire` varchar(255) NOT NULL,
  `delivery_tire` date NOT NULL,
  `detail_order` text NOT NULL,
  `pict_down_payment` varchar(255) DEFAULT NULL,
  `price_down_payment` varchar(255) DEFAULT NULL,
  `status_dp` varchar(255) DEFAULT NULL,
  `pict_full_payment` varchar(255) DEFAULT NULL,
  `price_full_payment` varchar(255) DEFAULT NULL,
  `status_fp` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) NOT NULL,
  `tire_status` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `production_file` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_queue_number_unique` (`queue_number`),
  KEY `orders_user_id_foreign` (`user_id`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.orders: ~2 rows (approximately)
INSERT INTO `orders` (`id`, `order_code`, `queue_number`, `book_date`, `total_tire`, `size_tire`, `delivery_tire`, `detail_order`, `pict_down_payment`, `price_down_payment`, `status_dp`, `pict_full_payment`, `price_full_payment`, `status_fp`, `payment_status`, `tire_status`, `status`, `user_id`, `created_at`, `updated_at`, `production_file`, `due_date`) VALUES
	(13, 'OSN-GLN2911686923896', '1', '2023-06-16', 10, '1000-300', '2023-06-17', 'Michellin Tire', '1686924030_WhatsApp Image 2023-06-15 at 8.21.03 PM.jpeg', '3500000', 'approved', '1686926016_WhatsApp_Image_2023-06-15_at_8.21.03_PM-removebg-preview (1).png', '5000000', 'approved', 'paid', 'success', 'approved', 5, '2023-06-16 06:58:16', '2023-06-16 08:15:13', '1686928513_inspection.pdf', NULL),
	(14, 'OSN-JIE0531687434516', '2', '2023-06-23', 50, '1000-300', '2023-06-23', 'Good Year Tire Pro', '1687434748_Payment.png', '12000000', 'approved', '1687435811_Screenshot (1).png', '3000000', 'approved', 'paid', 'success', 'approved', 5, '2023-06-22 04:48:36', '2023-06-22 05:11:35', '1687435895_Payment.pdf', '2023-06-26');

-- Dumping structure for table ossiana_db.password_reset_tokens
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.password_reset_tokens: ~0 rows (approximately)

-- Dumping structure for table ossiana_db.personal_access_tokens
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.personal_access_tokens: ~0 rows (approximately)

-- Dumping structure for table ossiana_db.report_tablet
CREATE TABLE IF NOT EXISTS `report_tablet` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `inspection_id` bigint(20) unsigned NOT NULL,
  `file_report_production` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_tablet_user_id_foreign` (`user_id`),
  KEY `report_tablet_order_id_foreign` (`order_id`),
  KEY `report_tablet_inspection_id_foreign` (`inspection_id`),
  CONSTRAINT `report_tablet_inspection_id_foreign` FOREIGN KEY (`inspection_id`) REFERENCES `inspections` (`id`),
  CONSTRAINT `report_tablet_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `report_tablet_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.report_tablet: ~0 rows (approximately)

-- Dumping structure for table ossiana_db.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.roles: ~2 rows (approximately)
INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'admin', '2023-05-27 00:03:32', '2023-05-27 00:03:32'),
	(2, 'customer', '2023-05-27 00:03:32', '2023-05-27 00:03:32'),
	(3, 'manager', '2023-05-27 00:03:32', '2023-05-27 00:03:32');

-- Dumping structure for table ossiana_db.schedullers
CREATE TABLE IF NOT EXISTS `schedullers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint(20) unsigned NOT NULL,
  `inspection_id` bigint(20) unsigned NOT NULL,
  `total_tire` int(11) NOT NULL,
  `initial_inspection` int(11) NOT NULL,
  `washing` int(11) NOT NULL,
  `hotroom` int(11) NOT NULL,
  `flexible_buffing` int(11) NOT NULL,
  `tire_washing` int(11) NOT NULL,
  `cementing` int(11) NOT NULL,
  `building_perfection` int(11) NOT NULL,
  `grooving` int(11) NOT NULL,
  `curing` int(11) NOT NULL,
  `finishing` int(11) NOT NULL,
  `final_inspection` int(11) NOT NULL,
  `total_hour` int(11) NOT NULL,
  `estimasi_due_date` date NOT NULL,
  `start_reparation_date` date NOT NULL,
  `end_reparation_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedullers_order_id_foreign` (`order_id`),
  KEY `schedullers_inspection_id_foreign` (`inspection_id`),
  CONSTRAINT `schedullers_inspection_id_foreign` FOREIGN KEY (`inspection_id`) REFERENCES `inspections` (`id`),
  CONSTRAINT `schedullers_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.schedullers: ~0 rows (approximately)
INSERT INTO `schedullers` (`id`, `order_id`, `inspection_id`, `total_tire`, `initial_inspection`, `washing`, `hotroom`, `flexible_buffing`, `tire_washing`, `cementing`, `building_perfection`, `grooving`, `curing`, `finishing`, `final_inspection`, `total_hour`, `estimasi_due_date`, `start_reparation_date`, `end_reparation_date`, `created_at`, `updated_at`) VALUES
	(3, 13, 3, 10, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 11, '2023-06-19', '2023-06-19', '2023-06-20', '2023-06-16 07:24:13', '2023-06-16 07:24:13'),
	(4, 14, 4, 50, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 22, '2023-06-26', '2023-06-24', '2023-06-28', '2023-06-22 05:08:20', '2023-06-22 05:08:20');

-- Dumping structure for table ossiana_db.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table ossiana_db.users: ~4 rows (approximately)
INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `phone`, `password`, `role_id`, `remember_token`, `created_at`, `updated_at`) VALUES
	(1, 'admin', 'admin@gmail.com', NULL, '+6285282205728', '$2y$10$9GJt92YmrM60ch0CFeef6Oe3qVLjdb6UZg7EvpAFbmpjIBiAu2OiO', 1, NULL, '2023-05-27 00:03:32', '2023-05-27 00:03:32'),
	(2, 'adzraa fadhilah', 'adzraa@gmail.com', NULL, '+6281351435460', '$2y$10$VmbPpvtNAlL5Evxr3030jO1AxzTuX8mfoTfLZiVgQ0EYgnblhRd3a', 2, NULL, '2023-05-27 00:03:32', '2023-05-27 00:03:32'),
	(3, 'manager', 'manager@gmail.com', NULL, '+6282112440715', '$2y$10$g5PkCATvY.zDb3TrhxPn4Oiwuz5jfqea9w5Mnyb0u.YY5yRZENsJK', 3, NULL, '2023-05-27 00:03:32', '2023-05-27 00:03:32'),
	(4, 'Rayhan yuda lesmana', 'rayhan@gmail.com', NULL, '+6285282205728', '$2y$10$nePxSglgrSJiApJEVBZDn.6w7tMCwwS5EYRRhyQwSbBVMsmwyZBVW', 2, NULL, '2023-05-27 00:04:28', '2023-05-27 00:04:28'),
	(5, 'Samsudin', 'samsudin@gmail.com', NULL, '+6285282205729', '$2y$10$3N46udbgfD2kb8U.Gtes6uOVJEv0j2krMwlMmccZ1bffD4ucvMkca', 2, NULL, '2023-05-27 02:07:07', '2023-05-27 02:07:07');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
